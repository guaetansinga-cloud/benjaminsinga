# Youth Unemployment and Civil Crises in Sub-Saharan Africa
Author: Deubou Singa Benjamin Guaetan

This repository contains the paper, notebook, data, and outputs for the seminar assignment.
Files:
- paper/Youth_Unemp_Conflict_SSA_Deubou.pdf
- paper/Youth_Unemp_Conflict_SSA_Deubou.docx
- notebooks/youth_unemployment_conflict_analysis_FIXED_v2.ipynb (please move the fixed notebook here)
- data/raw/ucdp_country_year.csv (synthetic created for testing; replace with real UCDP)
- data/processed/wdi_ssa_2000_2023.csv
- outputs/* (figures and regression tables)

Instructions:
1. Replace the synthetic UCDP file at data/raw/ucdp_country_year.csv with the real UCDP country-year CSV (download from UCDP website).
2. Open the notebook in notebooks/ and run all cells. The notebook will update outputs and regression tables.
3. Replace placeholders in the paper with actual outputs as required by the seminar.